$("#numberField").on('keyup',function () {
  $("#showTranslate").html('');
  let translate = amountTranslate($(this).val());
  $("#showTranslate").html((nullEmptyUndefinedChecked(translate) == false) ? translate+' Taka Only' : '');
});
